import processing.core.*;

import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.*;
import java.util.stream.Collectors;

public class drawPoints extends PApplet {

	public void settings() {
		size(500, 500);
	}

	public void setup() {
		background(180);
		noLoop();
	}

	public void draw() {

		double x, y;

		String[] lines = loadStrings("/Users/sankalpvarshney/IdeaProjects/203_labs_projects/lab8/drawMe.txt");
		println("there are " + lines.length);
		for (int i=0; i < lines.length; i++){
			if (lines[i].length() > 0 ) {
				String[] words= lines[i].split(",");
				x = Double.parseDouble(words[0]);
				y = Double.parseDouble(words[1]);
				println("xy: " + x + " " + y);
				ellipse((int)x, (int)y, 1, 1);
			}
		}
	}


	public static void main(String args[]) {
		PApplet.main("drawPoints");

		List<Point> points = new ArrayList<>();


		try{
			Scanner s = new Scanner(new FileReader("/Users/sankalpvarshney/IdeaProjects/203_labs_projects/lab8/positions.txt"));

			while (s.hasNext()){
				String[] values = s.nextLine().split(",");
				points.add(new Point(Double.parseDouble(values[0]), Double.parseDouble(values[1]),
						Double.parseDouble(values[2])));
				s.nextLine();
			}

		}catch(Exception e){
			System.out.println("can't get into input file!");
		}

		List<Point> translate = points.stream().filter(p -> p.getZ() <= 2.0).
				map(p -> new Point (p.getX()*0.5, p.getY()*0.5, p.getZ())).
				map(p -> new Point (p.getX() -100, p.getY() -37, p.getZ())).collect(Collectors.toList());


		try{
			PrintStream printStream = new PrintStream("/Users/sankalpvarshney/IdeaProjects/203_labs_projects/lab8/drawMe.txt");
			for(Point p: translate){
				printStream.println(Double.toString(p.getX()) + ", " + Double.toString(p.getY()) + ", " + Double.toString(p.getZ()));
			}
		}catch(Exception e){
			System.out.println("can't write into the file");
		}

	}
}
